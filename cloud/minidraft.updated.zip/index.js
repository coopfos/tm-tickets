const { app } = require('@azure/functions');
const { DefaultAzureCredential } = require('@azure/identity');
const { BlobServiceClient } = require('@azure/storage-blob');
const { TableClient } = require('@azure/data-tables');
const crypto = require('crypto');

const credential = new DefaultAzureCredential();
const blobUrl = process.env.STORAGE_BLOB_URL;
const tableUrl = process.env.STORAGE_TABLE_URL;
const containerName = (process.env.DRAFTS_CONTAINER || 'tickets-draft').trim();
const blobService = new BlobServiceClient(blobUrl, credential);
const referenceTableName = (process.env.REFERENCE_TABLE_NAME || 'Reference').trim();
const tableClient = new TableClient(tableUrl, referenceTableName, credential);

function guid() {
  return ([1e7]+-1e3+-4e3+-8e3+-1e11).replace(/[018]/g, c =>
    (c ^ crypto.randomBytes(1)[0] & 15 >> c / 4).toString(16)
  );
}

app.http('drafts-create', {
  methods: ['POST'],
  authLevel: 'anonymous',
  route: 'tickets/draft',
  handler: async (req, ctx) => {
    try {
      const body = await req.json();
      const id = (body && body.id) || guid();
      const now = new Date().toISOString();
      const payload = { id, savedAt: now, ...body };

      const container = blobService.getContainerClient(containerName);
      await container.createIfNotExists();
      const blobName = `${id}.json`;
      const blockBlob = container.getBlockBlobClient(blobName);
      const text = JSON.stringify(payload);
      await blockBlob.upload(text, Buffer.byteLength(text), {
        blobHTTPHeaders: { blobContentType: 'application/json' }
      });

      return { status: 201, jsonBody: { id, savedAt: now } };
    } catch (e) {
      ctx.error('drafts-create error', e);
      return { status: 500, jsonBody: { error: e.message || 'Server error' } };
    }
  }
});

// GET /api/tickets/draft/{id}
app.http('drafts-get', {
  methods: ['GET'],
  authLevel: 'anonymous',
  route: 'tickets/draft/{id}',
  handler: async (req, ctx) => {
    try {
      const id = req.params.id;
      if (!id) return { status: 400, jsonBody: { error: 'Missing id' } };
      const container = blobService.getContainerClient(containerName);
      const blobName = `${id}.json`;
      const blockBlob = container.getBlockBlobClient(blobName);
      if (!(await blockBlob.exists())) return { status: 404, jsonBody: { error: 'Not found' } };
      const resp = await blockBlob.download();
      const chunks = [];
      for await (const chunk of resp.readableStreamBody) { chunks.push(Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk)); }
      const text = Buffer.concat(chunks).toString('utf8');
      return { status: 200, jsonBody: JSON.parse(text) };
    } catch (e) {
      ctx.error('drafts-get error', e);
      return { status: 500, jsonBody: { error: e.message || 'Server error' } };
    }
  }
});

// GET /api/tickets/next-number -> { ticketNumber }
app.http('tickets-next-number', {
  methods: ['GET'],
  authLevel: 'anonymous',
  route: 'tickets/next-number',
  handler: async (req, ctx) => {
    const prefix = (process.env.TICKET_NUMBER_PREFIX || 'T-').trim();
    const start = parseInt(process.env.TICKET_NUMBER_START || '1000', 10) || 1000;
    const pk = 'ticket-seq';
    const rk = 'counter';
    const maxRetries = 5;
    try {
      await tableClient.createTable();
    } catch {}
    for (let attempt = 0; attempt < maxRetries; attempt++) {
      try {
        let entity;
        try {
          entity = await tableClient.getEntity(pk, rk);
        } catch (e) {
          // initialize at start-1 so first increment equals start
          await tableClient.createEntity({ partitionKey: pk, rowKey: rk, value: start - 1 });
          entity = await tableClient.getEntity(pk, rk);
        }
        const current = Number(entity.value || 0);
        const next = current + 1;
        // optimistic update using etag
        await tableClient.updateEntity({ partitionKey: pk, rowKey: rk, value: next }, 'Replace', { etag: entity.etag });
        const ticketNumber = `${prefix}${next}`;
        return { status: 200, jsonBody: { ticketNumber } };
      } catch (e) {
        // on precondition failed, retry
        if (String(e.message || '').includes('PreconditionFailed')) {
          await new Promise(r => setTimeout(r, 50 * (attempt + 1)));
          continue;
        }
        ctx.error('tickets-next-number error', e);
        return { status: 500, jsonBody: { error: e.message || 'Server error' } };
      }
    }
    return { status: 503, jsonBody: { error: 'Sequence contention, try again' } };
  }
});

// GET /api/reference/job-numbers/{jobNumber}
app.http('reference-job-get', {
  methods: ['GET'],
  authLevel: 'anonymous',
  route: 'reference/job-numbers/{jobNumber}',
  handler: async (req, ctx) => {
    const rowKeyRaw = (req.params.jobNumber || '').trim();
    const rowKey = rowKeyRaw;
    if (!rowKey) return { status: 400, jsonBody: { error: 'Missing jobNumber' } };
    const pk = 'job-numbers';
    try {
      let entity;
      try {
        entity = await tableClient.getEntity(pk, rowKey);
      } catch (e) {
        // Try uppercase fallback
        const up = rowKey.toUpperCase();
        if (up !== rowKey) {
          entity = await tableClient.getEntity(pk, up);
        } else {
          throw e;
        }
      }
      // Normalize entity properties to plain JSON with fallbacks for various column names
      const description = entity.Description || entity.description || entity.JobName || entity.jobName || entity.NAME || entity.Name;
      const customerName = entity.CustomerName || entity.customerName || entity.Customer || entity.customer;
      const result = {
        PartitionKey: entity.partitionKey,
        RowKey: entity.rowKey,
        Description: description,
        Status: entity.Status,
        CustomerName: customerName
      };
      return { status: 200, jsonBody: result };
    } catch (e) {
      const msg = String(e.message || '');
      if (msg.includes('The specified resource does not exist') || msg.includes('NotFound')) {
        return { status: 404, jsonBody: { error: 'Not found' } };
      }
      ctx.error('reference-job-get error', e);
      return { status: 500, jsonBody: { error: e.message || 'Server error' } };
    }
  }
});

// GET /api/reference/job-numbers?prefix=J-10 -> list jobs (RowKey starts with prefix)
app.http('reference-job-list', {
  methods: ['GET'],
  authLevel: 'anonymous',
  route: 'reference/job-numbers',
  handler: async (req, ctx) => {
    const url = new URL(req.url);
    const prefix = (url.searchParams.get('prefix') || '').trim();
    const pk = "job-numbers";
    const items = [];
    try {
      let filter = `PartitionKey eq '${pk}'`;
      if (prefix) {
        // Prefix range filter: RowKey >= prefix AND RowKey < prefix + \uffff
        const upper = prefix.toUpperCase();
        const hi = upper + "\uffff";
        filter += ` and RowKey ge '${upper}' and RowKey lt '${hi}'`;
      }
      const iter = tableClient.listEntities({ queryOptions: { filter } });
      let count = 0, max = 50;
      for await (const entity of iter) {
        const description = entity.Description || entity.description || entity.JobName || entity.jobName || entity.NAME || entity.Name;
        const customerName = entity.CustomerName || entity.customerName || entity.Customer || entity.customer;
        items.push({
          RowKey: entity.rowKey,
          Description: description,
          CustomerName: customerName,
          Status: entity.Status
        });
        count++;
        if (count >= max) break;
      }
      return { status: 200, jsonBody: { items } };
    } catch (e) {
      ctx.error('reference-job-list error', e);
      return { status: 500, jsonBody: { error: e.message || 'Server error' } };
    }
  }
});

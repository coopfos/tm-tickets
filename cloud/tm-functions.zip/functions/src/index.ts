// Entry point that loads all function definitions
import "./functions/reference";
import "./functions/drafts";
import "./functions/complete";

